#include <iostream>
#include <vector>
#include <chrono>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>
#include <iomanip>

using namespace std;

string getInput()
{
  string input;
  cout << "[cmd]: " ;
  getline(cin, input);
  return input;
}

void printHistory(vector<string> history)
{
  for( int i=0; i < history.size(); i++ )
  {
    cout << i+1 << ": " << history[i] << endl;
  }
}

void printCommandError(string input)
{
  cout << "Error: " << input << " is an invalid command" << endl;
}

int main(int argc, char* argv[])
{
  vector<string> history;
  string input;
  std::chrono::duration<double> time(0);

  input = getInput();

  while(input != "exit")
  {
      bool error(false);
      if (input[0] == '^')
      {
        input = input.substr(2);
        int index = stoi(input)-1;
        if(index < history.size())
        {
          input = history[index];
        }
        else
        {
          cout << "Error: Command index " << input << " not in history." << endl;
          error = true;
        }
      }

      if(!error)
      {
    if(input == "history")
    {
      history.push_back(input);
      printHistory(history);
    }
    else if(input == "ptime")
    {
      history.push_back(input);
      cout << "Time spent executing child processes: " << fixed << setprecision(4) << time.count() << " seconds" << endl;
    }
    else
    {

        history.push_back(input);
        
        //auto pid = fork();
        
        if(fork())
        {
          
          std::chrono::time_point<std::chrono::high_resolution_clock> start = std::chrono::high_resolution_clock::now();
          wait(NULL);
          std::chrono::time_point<std::chrono::high_resolution_clock> end = std::chrono::high_resolution_clock::now();
          
          time += end - start;
          
        }
        else 
        {
          
          vector<string> newinputs;
          int first=0;
          
          while(input[0] == ' ')
          {
            input.erase(0,1);
          }
          while(input[input.size()-1] == ' ')
          {
            input.erase(input.end());
          }

          for(int i = 0; i < input.size(); i++)
          {
            if(input[i] == ' ')
            {
              newinputs.push_back(input.substr(first, i-first));
              if(i+1 < input.size())
              {
                int iter = 1;
                while(input[i+iter] == ' ')
                {
                  input.erase(i+iter,1);
                }
                first = i+1;
              }
            }
          }
          newinputs.push_back(input.substr(first));
          
          char ** newargv = new char*[newinputs.size()+1];

          for(int i = 0; i < newinputs.size(); i++)
          {
            newargv[i] = new char[newinputs[i].size()+1];
            strcpy(newargv[i], newinputs[i].c_str());
          }
          newargv[newinputs.size()] = NULL; 
          
          
          execvp(newargv[0], newargv);
          printCommandError(input);
          exit(0);
        }
      }
    }
     
    input = getInput(); 
  }

  return 0;
}
